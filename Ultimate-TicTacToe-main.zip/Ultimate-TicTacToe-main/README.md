# Ultimate-TicTacToe
Just a fun project to make a game we used to play.
## Steps:
Just download the assets folder and the python script.
## If you want to play older versions:
Download the multiplayer_uttt.py file 
(This does require some setting up to do so it's recommended to ignore it)
